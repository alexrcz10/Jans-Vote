<?php
error_reporting(0);
$conexion= pg_connect("host=localhost port=5432 dbname=JansVote user=postgres password=jansvote") or die ("No se pudo conectar con la base de datos");

?>
